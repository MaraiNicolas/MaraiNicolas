package com.example.demo.Persona;

public enum Sexo {
    FEMENINO,
    MASCULINO
}
